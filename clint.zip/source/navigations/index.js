import {createSwitchNavigator,createBottomTabNavigator} from 'react-navigation';
import { fromLeft,zoomIn,zoomOut,fadeIn,fadeOut,flipX,flipY,fromBottom } from 'react-navigation-transitions';
import {createStackNavigator} from 'react-navigation-stack';
import * as containers from '../containers';


const MainStack = createStackNavigator({
    Home:{
        screen:containers.Main
    },
    Trips:{
        screen:containers.Trips
    }
},{headerMode:'none',transitionConfig: () => zoomIn()});
/*--Static-Routes--*/
export const Routes = {
    AppLoader:{
        screen:containers.AppLoader
    },
    Auth:{
        screen:containers.Auth
    },
    Main:{
        screen:MainStack
    }
};