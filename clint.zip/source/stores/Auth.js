import {observable,computed,action} from 'mobx';
import axios from 'axios';
import { AsyncStorage } from 'react-native';
import publicIP from 'react-native-public-ip';
import {helper} from '../service';
export default class Auth {
    /*--Static Value--*/
    @observable method = 'main'; // Auth Methods 

    /** Device & info */
    @observable ip = '';
    @observable country_code = '';

    /** Sms activate */
    @observable sms_code = '';

    /** User Stores */
    @observable user_input = {phone:'',password:'',method:'none'};
    @observable user_profile = {first_name:null,last_name:null,country:null,state:null,city:'null',address:null,zip:null};
    @observable user_car = {model:null,car_make:null,car_model:null,car_color:null};
    @observable user_card = {};
    @observable have_card = false;
    @observable settings = null;

    /** Login */
    @observable user_login ={phone:'',password:''};
    /** Auth Users */
    @observable user = {};
    @observable token = '';
    @observable active_car = {};
    /** Actions  */
    
    //@change auth methods 
    @action change_method (type) {
        this.method = type;
    }

    @action install(navigation) {
        navigation.navigate('Auth');
    }

    @action _register = async(navigation) => {
        let vaild = false;
        await axios.post(this.settings.serverUri + 'api/client/auth/register', {user_input:this.user_input,user_car:this.user_car,user_profile:this.user_profile,user_card:this.user_card,have_card:this.have_card}).then(async(response) => {
            console.log(response.data.user);
            this.user = await response.data.user;
            this._user_confirm();
            this.token = response.data.token;
            axios.defaults.headers.common['Authorization'] = 'Bearer ' + response.data.token;
            await AsyncStorage.setItem('token',response.data.token);
            vaild = true;
        }).catch(err => {
            console.log(err.response);
            vaild = false;
        });
        return vaild;
    }

    @action _login = async(navigation) => {
        let vaild = true;
        await axios.post(this.settings.serverUri + 'api/client/auth/login',this.user_login).then(async(response) => {
            console.log(response.data.user);
            this.user = await response.data.user;
            this._user_confirm();
            this.token = response.data.token;
            axios.defaults.headers.common['Authorization'] = 'Bearer ' + response.data.token;
            await AsyncStorage.setItem('token',response.data.token);
            setTimeout(() => {
                navigation.navigate('Main');
            });
        }).catch(err => {
            console.log(err.response);
            vaild = false;
        });
        return vaild;
    }

    @action _auth = async(navigation) => {
        let self = this;
        // var distance = helper.point_distance([32.351212,36.208356],[32.343327,36.204195]);
        // Last function to get the closest driver 
        try {
            let token = await AsyncStorage.getItem('token');
            if(token !== null) {
                axios.defaults.headers.common['Authorization'] = 'Bearer ' + token;
                axios.get(self.settings.serverUri + 'api/client/auth/index').then(response => {
                    self.user = response.data;
                    self._user_confirm();
                    navigation.navigate('Main');
                }).catch(err => {
                    console.log(err)
                    this.fetch_info();
                    navigation.navigate('Auth');
                });
            }else {
                this.fetch_info();
                navigation.navigate('Auth');
            }
        } catch (error) {
            this.fetch_info();
            navigation.navigate('Auth');
        }
    }

    @action _user_confirm() {
        this.user.user_car.forEach((trg,index) => {
            if(index == 0) {
                this.user.user_car[index].active = true;
                this.active_car = this.user.user_car[index];
            }else {
                this.user.user_car[index].active = false;
            }
        });
    }

    @action _make_car_active(car_index) {
        this.user.user_car.forEach((trg,index) => {
            if(trg.id == car_index) {
                this.user.user_car[index].active = true;
                this.active_car = this.user.user_car[index];
            }else {
                this.user.user_car[index].active = false;
            }
        });
    }

    @action fetch_info = async() => {
        let ip = await publicIP().then(ip => {
            this.ip = ip;
            return ip;
        }).catch(err => {
            console.log(err);
        });
        axios.get('https://api.ipgeolocationapi.com/geolocate/' + ip).then(response => {
            this.country_code = '+' + response.data.country_code;
            console.log(this.country_code);
        }).catch(err => {
            console.log(err)
        });
    }

    @action make_sms_vertify() {
        var val = Math.floor(1000 + Math.random() * 9000);
        this.sms_code = val;

        axios.post(this.settings.socketUri + 'send_sms', {code:this.sms_code,number:this.country_code + this.user_input.phone}).then(response => {
        }).catch(err => {
            console.log(err.response);
        });

    }

   constructor(Settings) {
    /*--When-Fire--*/
    this.settings = Settings;
   }
}