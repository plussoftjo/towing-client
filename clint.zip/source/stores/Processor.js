import {observable,computed,action} from 'mobx';

export default class Processor {
    /** This is car type
     * Car type 0 = Light duty
     * Car type 1 = Medium duty
     * Car type 2 = Large Duty
     */
    @observable car_type = 0;

    /** Service
     * Main Service type * What the main service the client need it 
     * Sub Service type * if have sub service 
     * note -> if type note in it 
     */
    @observable service = {
        main_service:'',
        sub_service:'',
        note:'',
        order_id:0,
        direction_name:'',
        direction_polyline:{},
        have_towing:false
    };


    /*** Driver Details coming from the socket */
    @observable driver = {};
    @observable coords = {};
    @observable distance = {};




    @action register_driver(driver,coords) {
        this.driver = driver;
        this.coords = coords;

        console.log(coords);
    }

}