/** Lottie Files */

const LottieFiles = {
    FindLocation:require('../../assets/lotties/FindLocation.json'),
    FindDriver:require('../../assets/lotties/FindDriver.json'),
    progress:require('../../assets/lotties/done.json')
};

export default LottieFiles;