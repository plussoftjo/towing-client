
const StylesColor = {
    Borders:'#BDBDBD',
    labels:'#E0E0E0'
}


export default {
    StylesColor
}