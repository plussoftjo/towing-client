
const CarColors = ['Silver','White','Black','Med. Dark Blue','Med. Dark Gray','Med. Red','Med. Dark Green','Light Brown','Bright Red','Gold','White Metallic','Med/Dk. Blue','Med./Dk. Gray','Med. Red','Med/Dk Green','Light Brown'];

export default CarColors;