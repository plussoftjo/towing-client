/**
 * Types
 */

 const Typs = {
    carsType:[
        {text:'Light Duty',image:require('../images/light.png'),active:true},
        {text:'Medium duty',image:require('../images/meduim.png'),active:false},
        {text:'heavy duty',image:require('../images/heavy.png'),active:false},
    ]
 };

 export default Typs;