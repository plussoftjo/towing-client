import CarModel from './CarModel';

export {
    CarModel
}