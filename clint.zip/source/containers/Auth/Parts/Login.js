import React from 'react';
import {View} from 'react-native';
import {Images, Colors} from '../../../commons';
import {Container,Content,Text,Item,Icon,Input,Button} from 'native-base';
import {inject,observer} from 'mobx-react';

@inject('auth')
@observer
export default class Login extends React.Component {
    constructor(props) {
        super(props);

        this.state = {vaild:true,pressed:false}
    }
    render() {
        return (
            <Container style={{backgroundColor:'transparent'}}>
                <Content padder contentContainerStyle={{ justifyContent: 'center', flex: 1 }}>
                    <Text style={{color:'white',fontWeight:'600',fontSize:26}}>Sign in</Text>
                    <View style={{height:20}}></View>
                    <Item regular style={{backgroundColor:'white'}} rounded>
                        <Icon active type="AntDesign" name='phone' />
                        <Input placeholder={this.props.translate('form.phone')} keyboardType='numeric' value={this.props.auth.user_login.phone} onChangeText={(value) =>{this.props.auth.user_login.phone = value;}}/>
                    </Item>
                    <View style={{height:20}}></View>
                    <Item regular style={{backgroundColor:'white'}} rounded>
                        <Icon active type="AntDesign" name='key' />
                        <Input placeholder={this.props.translate('form.password')} secureTextEntry={true} value={this.props.auth.user_login.password} onChangeText={(value) => {this.props.auth.user_login.password = value;}}/>
                    </Item>
                    {!this.state.vaild &&
                    <Text style={{color:'red',fontWeight:'500',marginBottom:10}}>There are error in phone/password</Text>
                    }
                    <View key="button" style={{flexDirection:'row',justifyContent:'flex-end',marginRight:0,marginTop:30}}>
                    <Button success onPress={async() => {
                        let login = await this.props.auth._login(this.props.navigation);
                        if(!login) { 
                            this.setState({vaild:false})
                        }
                        }} style={{borderRadius:30,justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                        <Text style={{color:'white',fontWeight:'700'}}>Login</Text>
                        <Icon name='arrow-forward' style={{textAlign:'center',color:'white',fontSize:32}} />
                    </Button>
                </View>
                </Content>
            </Container>
        )
    }
}