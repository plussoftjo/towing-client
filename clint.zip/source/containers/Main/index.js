import React from 'react';

/** Components */
import MapView from 'react-native-maps';
import { StyleSheet, Text, View, Dimensions,TouchableOpacity } from 'react-native';
import {Icon,Drawer} from 'native-base';
import {StepManger,LocationLoader,DirectionsPoly,DriverDirectionsPoly,MapPartManger,DrawerLayout} from '../../components'

/** Expo Librarys */
import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions';

/** Service */
import {permissions} from '../../service'
import {inject,observer} from 'mobx-react';

/** Styles */
import {styles} from './styles';

/** injection stores  */
@inject('languages')
@inject('locations')
@inject('drivers')
@inject('manger')
@inject('socketmanger')
@observer
export default class Main extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isReady:false
        };
    }

    // componentDidMount() {
    //     this._install_coords();// Install Coords
    // }

    componentWillMount() {
        this._install_coords();
    }
    _install_coords = async() => {
        /** Install Coords */
        let {status} = await Permissions.askAsync(Permissions.LOCATION);// Check Permissions
        if(status !== 'granted') {permissions._onPermissionDeney();} // If Permissions Deney
        let location = await Location.getCurrentPositionAsync(); // Get Coords
        this.setState({isReady:true});

        /** Register to the stores */
        this.props.locations.register_user_coords(location.coords);
        this.props.locations.register_map_coords(location.coords);

        /** Install check driver to the closeits drivers */
        this.props.drivers._get_nerist_drivers(location.coords);
    }

    navigate_to_user_coords() {
        this.map.animateToRegion({
            latitude:this.props.locations.user_coords.latitude,
            longitude:this.props.locations.user_coords.longitude,
            latitudeDelta:0.015,
            longitudeDelta:0.0121
        });
    }

    closeDrawer = () =>  {
        this.drawer._root.close();
    };

    
    /** render() */
    render() {
        /** Consents */
        let translate = this.props.languages.translate;
        let locations = this.props.locations;
        /** Return Methods */
        return (
            <Drawer  openDrawerOffset={0.30} panCloseMask={0.35} onClose={() => this.closeDrawer()} ref={(ref) => { this.drawer = ref; }} content={<DrawerLayout closeDrawer={this.closeDrawer} navigation={this.props.navigation}/>}style={styles.container} >
                {/** Map View
                 * @action Show Current Postition when Loaded
                 * @disable_now any live location to finish load 
                 */}
                <MapView 
                style={styles.mapStyle} 
                provider={'google'}
                ref={map => {this.map = map;}}
                customMapStyle={require('../../commons/MapStyle.json')}
                region={{
                    latitude:locations.map_coords.latitude,
                    longitude:locations.map_coords.longitude,
                    latitudeDelta:this.state.isReady?0.015:0.99,
                    longitudeDelta:this.state.isReady?0.0121:0.99
                }}
                showsUserLocation={true}
                >
                    {/** Maps Collictions
                     * @Step 2
                     * @show directions between tow points
                     */}
                    {/* <DirectionsPoly map={this.map} /> */}
                    {this.state.isReady &&
                    <MapPartManger coords={locations.map_coords} map={this.map} />
                    }
                </MapView>


                {/**
                 * Pin Icon
                 */}
                <TouchableOpacity onPress={() => {this.navigate_to_user_coords();}} style={{position:'absolute',bottom:'5%',right:'5%',width:45,height:45,backgroundColor:'black',justifyContent:'center',alignContent:'center',alignItems:'center',borderRadius:45 / 2}}>
                    <Icon name="navigation" type="Feather" style={{color:'white',fontSize:22}} />
                </TouchableOpacity>
                

                {/** Loader 
                 * @action Destroy When Comblete
                 * @disaply LottieView -> animation Loader
                 */}
                 {!this.state.isReady &&
                    <LocationLoader/>
                 }


                 {/** Step Manger
                  * @action Show When Ready with animation
                  * @medthod Show All the Manger Steps in containers
                  */}
                  {this.state.isReady && 
                    <StepManger map={this.map} drawer={this.drawer._root}/>
                  }

                  
            </Drawer>
            );
        
    }
}